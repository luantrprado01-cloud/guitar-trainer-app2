package com.guitarratrainer.app2;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Bundle;
import android.os.Process;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.webkit.WebViewAssetLoader;

public class MainActivity extends Activity {
    private static final int REQ_AUDIO = 1001;
    private WebView webView;
    private PermissionRequest pendingAudioRequest;
    private boolean pendingNativeTunerStart = false;

    private volatile boolean nativeTunerRunning = false;
    private AudioRecord nativeAudioRecord;
    private Thread nativeTunerThread;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
        );

        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        // V9.1: force the embedded UI to refresh after an app update.
        // The appassets URL is stable between versions, so some WebViews may
        // otherwise keep serving the previous cached index.html.
        settings.setCacheMode(WebSettings.LOAD_NO_CACHE);
        webView.clearCache(true);

        final WebViewAssetLoader assetLoader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            @SuppressWarnings("deprecation")
            public WebResourceResponse shouldInterceptRequest(WebView view, String url) {
                return assetLoader.shouldInterceptRequest(Uri.parse(url));
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> {
                    boolean wantsAudio = false;
                    for (String resource : request.getResources()) {
                        if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(resource)) {
                            wantsAudio = true;
                            break;
                        }
                    }

                    if (!wantsAudio) {
                        request.deny();
                        return;
                    }

                    if (checkSelfPermission(Manifest.permission.RECORD_AUDIO)
                            == PackageManager.PERMISSION_GRANTED) {
                        request.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE});
                    } else {
                        pendingAudioRequest = request;
                        requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO);
                    }
                });
            }
        });

        // V8: o afinador usa AudioRecord nativo do Android. Isto evita falhas
        // de getUserMedia/WebRTC em alguns WebViews/telemóveis (incluindo Xiaomi).
        webView.addJavascriptInterface(new NativeTunerBridge(), "NativeTuner");

        webView.setBackgroundColor(0xFF0E0A07);
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html?v=9_1");
    }

    public class NativeTunerBridge {
        @JavascriptInterface
        public void start() {
            runOnUiThread(() -> startNativeTuner());
        }

        @JavascriptInterface
        public void stop() {
            runOnUiThread(() -> stopNativeTuner());
        }

        @JavascriptInterface
        public boolean isAvailable() {
            return true;
        }
    }

    private void startNativeTuner() {
        if (nativeTunerRunning) return;

        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
            pendingNativeTunerStart = true;
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO);
            sendNativeTunerStatus("A pedir permissão do microfone…");
            return;
        }

        final int[] sampleRates = new int[]{48000, 44100};
        AudioRecord recorder = null;
        int selectedRate = 0;
        int selectedBuffer = 0;

        for (int rate : sampleRates) {
            int minBuffer = AudioRecord.getMinBufferSize(
                    rate,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT
            );
            if (minBuffer <= 0) continue;
            int bufferSize = Math.max(minBuffer * 2, 8192);
            try {
                AudioRecord candidate = new AudioRecord(
                        MediaRecorder.AudioSource.DEFAULT,
                        rate,
                        AudioFormat.CHANNEL_IN_MONO,
                        AudioFormat.ENCODING_PCM_16BIT,
                        bufferSize
                );
                if (candidate.getState() == AudioRecord.STATE_INITIALIZED) {
                    recorder = candidate;
                    selectedRate = rate;
                    selectedBuffer = bufferSize;
                    break;
                }
                candidate.release();
            } catch (Exception ignored) {
            }
        }

        if (recorder == null) {
            sendNativeTunerStatus("Não foi possível inicializar o microfone do Android.");
            return;
        }

        nativeAudioRecord = recorder;
        final int sampleRate = selectedRate;
        final int readSize = Math.min(4096, Math.max(2048, selectedBuffer / 2));

        try {
            nativeAudioRecord.startRecording();
        } catch (Exception e) {
            try { nativeAudioRecord.release(); } catch (Exception ignored) {}
            nativeAudioRecord = null;
            sendNativeTunerStatus("O Android não conseguiu iniciar a gravação do microfone.");
            return;
        }

        if (nativeAudioRecord.getRecordingState() != AudioRecord.RECORDSTATE_RECORDING) {
            try { nativeAudioRecord.release(); } catch (Exception ignored) {}
            nativeAudioRecord = null;
            sendNativeTunerStatus("O microfone não entrou em modo de gravação.");
            return;
        }

        nativeTunerRunning = true;
        sendNativeTunerStatus("Ouvindo… toque uma corda");

        nativeTunerThread = new Thread(() -> {
            Process.setThreadPriority(Process.THREAD_PRIORITY_AUDIO);
            short[] buffer = new short[readSize];

            while (nativeTunerRunning && nativeAudioRecord != null) {
                int n;
                try {
                    n = nativeAudioRecord.read(buffer, 0, buffer.length);
                } catch (Exception e) {
                    n = -1;
                }

                if (n > 0) {
                    double pitch = detectPitchYin(buffer, n, sampleRate);
                    if (pitch > 0) sendNativePitch(pitch);
                    else sendNativeNoPitch();
                } else if (n < 0) {
                    sendNativeTunerStatus("Falha ao ler o microfone do Android.");
                    break;
                }
            }
        }, "GuitarTrainerNativeTuner");
        nativeTunerThread.start();
    }

    private void stopNativeTuner() {
        nativeTunerRunning = false;
        AudioRecord r = nativeAudioRecord;
        nativeAudioRecord = null;
        if (r != null) {
            try { r.stop(); } catch (Exception ignored) {}
            try { r.release(); } catch (Exception ignored) {}
        }
        Thread t = nativeTunerThread;
        nativeTunerThread = null;
        if (t != null) t.interrupt();
    }

    private double detectPitchYin(short[] input, int length, int sampleRate) {
        if (length < 1024) return 0;

        double rms = 0;
        for (int i = 0; i < length; i++) {
            double v = input[i] / 32768.0;
            rms += v * v;
        }
        rms = Math.sqrt(rms / length);
        if (rms < 0.006) return 0;

        final double minFreq = 70.0;
        final double maxFreq = 1200.0;
        int minTau = Math.max(2, (int) Math.floor(sampleRate / maxFreq));
        int maxTau = Math.min((int) Math.floor(sampleRate / minFreq), length / 2);
        if (maxTau <= minTau + 2) return 0;

        double[] diff = new double[maxTau + 1];
        for (int tau = 1; tau <= maxTau; tau++) {
            double sum = 0;
            int lim = length - tau;
            for (int i = 0; i < lim; i++) {
                double d = input[i] - input[i + tau];
                sum += d * d;
            }
            diff[tau] = sum;
        }

        double[] cmnd = new double[maxTau + 1];
        cmnd[0] = 1;
        double running = 0;
        for (int tau = 1; tau <= maxTau; tau++) {
            running += diff[tau];
            cmnd[tau] = running > 0 ? diff[tau] * tau / running : 1;
        }

        final double threshold = 0.14;
        int tauEstimate = -1;
        for (int tau = minTau; tau <= maxTau; tau++) {
            if (cmnd[tau] < threshold) {
                while (tau + 1 <= maxTau && cmnd[tau + 1] < cmnd[tau]) tau++;
                tauEstimate = tau;
                break;
            }
        }

        if (tauEstimate < 0) {
            int best = minTau;
            for (int tau = minTau + 1; tau <= maxTau; tau++) {
                if (cmnd[tau] < cmnd[best]) best = tau;
            }
            if (cmnd[best] > 0.28) return 0;
            tauEstimate = best;
        }

        double betterTau = tauEstimate;
        if (tauEstimate > 1 && tauEstimate < maxTau) {
            double s0 = cmnd[tauEstimate - 1];
            double s1 = cmnd[tauEstimate];
            double s2 = cmnd[tauEstimate + 1];
            double denominator = 2.0 * (2.0 * s1 - s2 - s0);
            if (Math.abs(denominator) > 1e-12) {
                betterTau = tauEstimate + (s2 - s0) / denominator;
            }
        }

        double frequency = sampleRate / betterTau;
        if (!Double.isFinite(frequency) || frequency < minFreq || frequency > maxFreq) return 0;
        return frequency;
    }

    private void sendNativePitch(double frequency) {
        if (webView == null) return;
        final String js = "window.onNativeTunerPitch&&window.onNativeTunerPitch(" + frequency + ");";
        runOnUiThread(() -> {
            if (webView != null) webView.evaluateJavascript(js, null);
        });
    }

    private void sendNativeNoPitch() {
        if (webView == null) return;
        runOnUiThread(() -> {
            if (webView != null) {
                webView.evaluateJavascript("window.onNativeTunerNoPitch&&window.onNativeTunerNoPitch();", null);
            }
        });
    }

    private void sendNativeTunerStatus(String status) {
        if (webView == null) return;
        String safe = status.replace("\\", "\\\\").replace("'", "\\'").replace("\n", " ");
        final String js = "window.onNativeTunerStatus&&window.onNativeTunerStatus('" + safe + "');";
        runOnUiThread(() -> {
            if (webView != null) webView.evaluateJavascript(js, null);
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_AUDIO) {
            boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;

            if (pendingAudioRequest != null) {
                if (granted) {
                    pendingAudioRequest.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE});
                } else {
                    pendingAudioRequest.deny();
                }
                pendingAudioRequest = null;
            }

            if (pendingNativeTunerStart) {
                pendingNativeTunerStart = false;
                if (granted) startNativeTuner();
                else sendNativeTunerStatus("Permissão do microfone negada.");
            }
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        stopNativeTuner();
        if (pendingAudioRequest != null) {
            pendingAudioRequest.deny();
            pendingAudioRequest = null;
        }
        if (webView != null) {
            webView.removeJavascriptInterface("NativeTuner");
            webView.destroy();
        }
        super.onDestroy();
    }
}
